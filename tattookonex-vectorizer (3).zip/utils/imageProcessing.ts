
import { CurvePoint } from '../types';

/**
 * Generates a Look-Up Table (LUT) of 256 values based on the curve points.
 * Uses linear interpolation between points.
 */
export const getCurveLUT = (points: CurvePoint[]): Uint8Array => {
  const lut = new Uint8Array(256);
  const sorted = [...points].sort((a, b) => a.x - b.x);

  for (let i = 0; i < 256; i++) {
    let p1 = sorted[0];
    let p2 = sorted[sorted.length - 1];

    for (let j = 0; j < sorted.length - 1; j++) {
      if (i >= sorted[j].x && i <= sorted[j + 1].x) {
        p1 = sorted[j];
        p2 = sorted[j + 1];
        break;
      }
    }

    if (p1.x === p2.x) {
      lut[i] = p1.y;
    } else {
      const t = (i - p1.x) / (p2.x - p1.x);
      lut[i] = Math.max(0, Math.min(255, Math.round(p1.y + t * (p2.y - p1.y))));
    }
  }
  return lut;
};

/**
 * Applies multiple LUTs to an image's pixel data.
 * Only 'all' (Master) and 'red' are used now.
 */
export const applyMultiChannelCurves = (
  pixels: Uint8ClampedArray, 
  luts: { all: Uint8Array, red: Uint8Array }
): Uint8ClampedArray => {
  const result = new Uint8ClampedArray(pixels.length);
  for (let i = 0; i < pixels.length; i += 4) {
    // 1. Appliquer la courbe du canal rouge si elle existe, les autres restent identiques
    let r = luts.red[pixels[i]];
    let g = pixels[i+1];
    let b = pixels[i+2];

    // 2. Appliquer la courbe maîtresse (Master RGB)
    result[i] = luts.all[r];
    result[i + 1] = luts.all[g];
    result[i + 2] = luts.all[b];
    result[i + 3] = pixels[i + 3];
  }
  return result;
};

/**
 * Fast K-Means implementation for image pixel clustering.
 * Added 'quality' parameter: 'low' uses fewer samples/iterations for real-time fluidity.
 */
export const runKMeans = (
  pixels: Uint8ClampedArray,
  k: number,
  isBlackAndWhite: boolean,
  quality: 'low' | 'high' = 'high'
): Uint8ClampedArray => {
  const data: number[][] = [];
  const pixelCount = pixels.length / 4;

  // Reduce work significantly for 'low' quality
  const sampleSize = quality === 'low' ? 2000 : 12000;
  const maxIterations = quality === 'low' ? 3 : 8;
  const step = Math.floor(pixelCount / sampleSize) || 1;
  
  for (let i = 0; i < pixelCount; i += step) {
    const r = pixels[i * 4];
    const g = pixels[i * 4 + 1];
    const b = pixels[i * 4 + 2];
    
    if (isBlackAndWhite) {
      const gray = 0.299 * r + 0.587 * g + 0.114 * b;
      data.push([gray]);
    } else {
      data.push([r, g, b]);
    }
  }

  let centroids = data
    .sort(() => 0.5 - Math.random())
    .slice(0, k);

  for (let iter = 0; iter < maxIterations; iter++) {
    const clusters: number[][][] = Array.from({ length: k }, () => []);
    for (const point of data) {
      let minDist = Infinity;
      let clusterIndex = 0;
      for (let j = 0; j < k; j++) {
        const dist = euclideanDistance(point, centroids[j]);
        if (dist < minDist) {
          minDist = dist;
          clusterIndex = j;
        }
      }
      clusters[clusterIndex].push(point);
    }
    centroids = clusters.map((cluster, i) => {
      if (cluster.length === 0) return centroids[i];
      const sum = cluster[0].map((_, dim) => 
        cluster.reduce((acc, p) => acc + p[dim], 0) / cluster.length
      );
      return sum;
    });
  }

  const result = new Uint8ClampedArray(pixels.length);
  for (let i = 0; i < pixelCount; i++) {
    const r = pixels[i * 4];
    const g = pixels[i * 4 + 1];
    const b = pixels[i * 4 + 2];
    const a = pixels[i * 4 + 3];

    let currentPoint: number[];
    if (isBlackAndWhite) {
      const gray = 0.299 * r + 0.587 * g + 0.114 * b;
      currentPoint = [gray];
    } else {
      currentPoint = [r, g, b];
    }

    let minDist = Infinity;
    let bestCentroid = centroids[0];
    for (const c of centroids) {
      const d = euclideanDistance(currentPoint, c);
      if (d < minDist) {
        minDist = d;
        bestCentroid = c;
      }
    }

    if (isBlackAndWhite) {
      const val = Math.round(bestCentroid[0]);
      result[i * 4] = val;
      result[i * 4 + 1] = val;
      result[i * 4 + 2] = val;
    } else {
      result[i * 4] = Math.round(bestCentroid[0]);
      result[i * 4 + 1] = Math.round(bestCentroid[1]);
      result[i * 4 + 2] = Math.round(bestCentroid[2]);
    }
    result[i * 4 + 3] = a;
  }
  return result;
};

const euclideanDistance = (a: number[], b: number[]): number => {
  return Math.sqrt(a.reduce((acc, val, i) => acc + Math.pow(val - b[i], 2), 0));
};

export const blendImages = (
  original: Uint8ClampedArray,
  processed: Uint8ClampedArray,
  opacity: number,
  isBlackAndWhite: boolean = false
): Uint8ClampedArray => {
  const result = new Uint8ClampedArray(original.length);
  const alpha = opacity / 100;
  
  for (let i = 0; i < original.length; i += 4) {
    let r1 = original[i];
    let g1 = original[i + 1];
    let b1 = original[i + 2];
    
    if (isBlackAndWhite) {
      const gray = 0.299 * r1 + 0.587 * g1 + 0.114 * b1;
      r1 = g1 = b1 = gray;
    }

    const r2 = processed[i];
    const g2 = processed[i + 1];
    const b2 = processed[i + 2];

    result[i] = Math.round(r1 * (1 - alpha) + r2 * alpha);
    result[i + 1] = Math.round(g1 * (1 - alpha) + g2 * alpha);
    result[i + 2] = Math.round(b1 * (1 - alpha) + b2 * alpha);
    result[i + 3] = original[i + 3];
  }
  return result;
};
